import test from 'node:test';
import assert from 'node:assert/strict';
import {
  filterProjects,
  formatCopyrightYear,
  getContactHref,
  isContactConfigured,
} from './portfolioHelpers';
import {
  CERTIFICATES_DATA,
  CONTACT_CHANNELS,
  PROJECTS_DATA,
} from '../data/portfolioData';

test('configured contact channels produce valid clickable hrefs', () => {
  const email = CONTACT_CHANNELS.find((c) => c.id === 'email');
  const linkedin = CONTACT_CHANNELS.find((c) => c.id === 'linkedin');
  assert.ok(email);
  assert.ok(linkedin);
  assert.equal(isContactConfigured(email), true);
  assert.equal(getContactHref(email), 'mailto:theintnandarsoe57889@gmail.com');
  assert.equal(isContactConfigured(linkedin), true);
  assert.equal(
    getContactHref(linkedin),
    'https://www.linkedin.com/in/thaint-nandar-soe-3309b63b3',
  );
});

test('empty contact channels are not treated as clickable links', () => {
  assert.equal(
    isContactConfigured({
      id: 'email',
      label: 'Email',
      placeholderText: '',
      value: '',
      helperText: '',
    }),
    false,
  );
  assert.equal(
    getContactHref({
      id: 'linkedin',
      label: 'LinkedIn',
      placeholderText: '',
      value: '',
      helperText: '',
    }),
    null,
  );
});

test('contact links reject dummy placeholders and activate on real details', () => {
  assert.equal(
    isContactConfigured({
      id: 'email',
      label: 'Email',
      placeholderText: '',
      value: 'divya@example.com',
      helperText: '',
    }),
    false,
  );

  assert.equal(
    getContactHref({
      id: 'email',
      label: 'Email',
      placeholderText: '',
      value: 'divya.lucknow@gmail.com',
      helperText: '',
    }),
    'mailto:divya.lucknow@gmail.com',
  );

  assert.equal(
    isContactConfigured({
      id: 'linkedin',
      label: 'LinkedIn',
      placeholderText: '',
      value: 'https://www.linkedin.com/in/your-profile',
      helperText: '',
    }),
    false,
  );

  assert.equal(
    getContactHref({
      id: 'linkedin',
      label: 'LinkedIn',
      placeholderText: '',
      value: 'https://www.linkedin.com/in/divya-cse-ai',
      helperText: '',
    }),
    'https://www.linkedin.com/in/divya-cse-ai',
  );
});

test('project filter returns expected subsets', () => {
  assert.equal(filterProjects(PROJECTS_DATA, 'All').length, 2);
  const practice = filterProjects(PROJECTS_DATA, 'Practice Project');
  assert.equal(practice.length, 1);
  assert.equal(practice[0].id, 'pk-prakriti-farm');
  assert.equal(practice[0].liveUrl, 'https://pk-prakriti-farm.ai.studio/');

  const inProgress = filterProjects(PROJECTS_DATA, 'In Progress');
  assert.equal(inProgress.length, 1);
  assert.equal(inProgress[0].id, 'personal-portfolio');
  assert.equal(inProgress[0].liveUrl, undefined);
});

test('copyright year formats single year or range automatically', () => {
  assert.equal(formatCopyrightYear(2026, 2026), '2026');
  assert.equal(formatCopyrightYear(2026, 2028), '2026–2028');
  assert.equal(formatCopyrightYear(2026, 2025), '2026');
});

test('certificate records preserve original holder names', () => {
  const hp = CERTIFICATES_DATA.find((c) => c.id === 'hp-life-ai-beginners');
  const be10x = CERTIFICATES_DATA.find((c) => c.id === 'be10x-ai-tools-claude');
  assert.ok(hp);
  assert.ok(be10x);
  assert.equal(hp.holderName, 'Thaint Nandar Soe');
  assert.equal(be10x.holderName, 'THAINT NANDAR SOE');
});
