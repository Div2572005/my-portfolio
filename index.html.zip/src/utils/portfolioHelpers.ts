import type { ContactChannel, ProjectItem, ProjectStatus } from '../data/portfolioData';

export type ProjectFilter = 'All' | ProjectStatus;

/**
 * Determines whether a contact channel has a real configured value
 * (and is not empty or a generic placeholder string).
 */
export function isContactConfigured(channel: ContactChannel): boolean {
  const trimmed = channel.value.trim();
  if (!trimmed) return false;

  const lower = trimmed.toLowerCase();
  if (
    lower.includes('example.com') ||
    lower.includes('your-profile') ||
    lower.includes('your-handle') ||
    lower.includes('placeholder')
  ) {
    return false;
  }

  if (channel.id === 'email') {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed);
  }

  if (channel.id === 'linkedin') {
    return /^https:\/\/(www\.)?linkedin\.com\/.+/i.test(trimmed);
  }

  return false;
}

/**
 * Builds the safe href for a configured contact channel, or null if not configured.
 */
export function getContactHref(channel: ContactChannel): string | null {
  if (!isContactConfigured(channel)) return null;
  const trimmed = channel.value.trim();
  return channel.id === 'email' ? `mailto:${trimmed}` : trimmed;
}

/**
 * Filters projects by status while preserving original order.
 */
export function filterProjects(
  projects: ProjectItem[],
  filter: ProjectFilter,
): ProjectItem[] {
  if (filter === 'All') return projects;
  return projects.filter((project) => project.status === filter);
}

/**
 * Formats an automatic copyright year or year range from a starting year.
 */
export function formatCopyrightYear(
  startYear: number,
  currentYear: number = new Date().getFullYear(),
): string {
  if (currentYear <= startYear) {
    return String(startYear);
  }
  return `${startYear}–${currentYear}`;
}
