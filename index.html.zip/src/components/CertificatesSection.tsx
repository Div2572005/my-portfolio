import { useState } from 'react';
import { Expand, ExternalLink, FileText } from 'lucide-react';
import { CERTIFICATES_DATA, type CertificateItem } from '../data/portfolioData';
import { CertificateLightbox } from './CertificateLightbox';

export function CertificatesSection() {
  const [selectedCertificate, setSelectedCertificate] = useState<CertificateItem | null>(null);
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});

  const handleImageError = (id: string) => {
    setFailedImages((prev) => ({ ...prev, [id]: true }));
  };

  return (
    <section
      id="certificates"
      aria-labelledby="certificates-heading"
      className="border-b border-white/10 bg-[#08101F] py-16 sm:py-20"
    >
      <div className="mx-auto max-w-6xl px-6">
        <div className="max-w-2xl">
          <p className="text-xs font-semibold tracking-wider text-[#60A5FA]">
            Coursework &amp; Workshops
          </p>
          <h2
            id="certificates-heading"
            className="mt-2 font-display text-2xl font-bold tracking-tight text-white sm:text-3xl"
          >
            Certificates &amp; Workshops
          </h2>
          <p className="mt-3 text-base leading-relaxed text-[#CBD5E1]">
            Original completion certificates from introductory AI courses and practical tool workshops, displayed without modification.
          </p>
        </div>

        <div className="mt-10 grid gap-8 lg:grid-cols-2">
          {CERTIFICATES_DATA.map((cert) => {
            const hasError = Boolean(failedImages[cert.id]);
            return (
              <article
                key={cert.id}
                className="flex flex-col justify-between rounded-2xl border border-white/12 bg-[#0F1A2E] p-6 transition-colors duration-150 hover:border-[#3B82F6]/45 sm:p-7"
              >
                <div>
                  {/* Aspect-ratio-preserving readable frame */}
                  <div className="flex h-72 w-full items-center justify-center overflow-hidden rounded-xl border border-white/10 bg-white p-3 sm:h-80">
                    {hasError ? (
                      <div
                        role="img"
                        aria-label={cert.altText}
                        className="flex h-full w-full flex-col items-center justify-center rounded-lg bg-[#08101F] p-5 text-center"
                      >
                        <FileText className="h-9 w-9 text-[#60A5FA]" aria-hidden="true" />
                        <p className="mt-3 font-display text-sm font-semibold text-white">
                          {cert.title}
                        </p>
                        <p className="mt-1 text-xs text-[#94A3B8]">
                          {cert.issuer} · {cert.holderName}
                        </p>
                        <p className="mt-2 text-xs text-[#60A5FA]">
                          Original PDF available below
                        </p>
                      </div>
                    ) : (
                      <img
                        src={cert.imageUrl}
                        alt={cert.altText}
                        loading="lazy"
                        referrerPolicy="no-referrer"
                        onError={() => handleImageError(cert.id)}
                        className="h-full w-full object-contain"
                      />
                    )}
                  </div>

                  {/* Unboxed metadata row */}
                  <div className="mt-6 flex flex-wrap items-center gap-2 text-xs font-medium">
                    <span className="text-[#60A5FA]">{cert.issuer}</span>
                    <span aria-hidden="true" className="text-[#475569]">
                      ·
                    </span>
                    <span className="text-[#94A3B8]">{cert.certificateTitle}</span>
                    <span aria-hidden="true" className="text-[#475569]">
                      ·
                    </span>
                    <span className="font-mono text-[#94A3B8] tabular-nums">
                      {cert.dateLabel} {cert.dateValue}
                    </span>
                  </div>

                  <h3 className="mt-2.5 font-display text-xl font-bold text-white">
                    {cert.title}
                  </h3>

                  <p className="mt-1 text-xs text-[#94A3B8]">
                    Name printed on certificate:{' '}
                    <span className="font-medium text-[#E2E8F0]">{cert.holderName}</span>
                  </p>

                  <p className="mt-3 text-sm leading-relaxed text-[#CBD5E1]">
                    {cert.description}
                  </p>

                  <div className="mt-4 border-t border-white/10 pt-4">
                    <p className="text-xs font-medium text-[#94A3B8]">{cert.topicsLabel}</p>
                    <ul className="mt-2 grid gap-1.5 text-xs text-[#CBD5E1] sm:grid-cols-2">
                      {cert.topics.map((topic) => (
                        <li key={topic} className="flex items-baseline gap-2">
                          <span aria-hidden="true" className="text-[#3B82F6]">
                            /
                          </span>
                          <span>{topic}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="mt-6 flex flex-wrap items-center gap-3 border-t border-white/10 pt-5">
                  <button
                    type="button"
                    onClick={() => setSelectedCertificate(cert)}
                    className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-[#3B82F6] px-5 py-2.5 text-sm font-semibold text-white whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-[#2563EB] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#60A5FA]"
                  >
                    <Expand className="h-4 w-4" aria-hidden="true" />
                    <span>View Certificate</span>
                  </button>

                  <a
                    href={cert.pdfUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl border border-white/20 bg-[#08101F] px-4 py-2.5 text-sm font-medium text-[#E2E8F0] whitespace-nowrap shrink-0 transition-colors duration-150 hover:border-[#3B82F6]/70 hover:text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#3B82F6]"
                  >
                    <ExternalLink className="h-4 w-4 text-[#60A5FA]" aria-hidden="true" />
                    <span>Open Original PDF</span>
                  </a>
                </div>
              </article>
            );
          })}
        </div>
      </div>

      <CertificateLightbox
        certificate={selectedCertificate}
        imageFailed={selectedCertificate ? Boolean(failedImages[selectedCertificate.id]) : false}
        onImageError={handleImageError}
        onClose={() => setSelectedCertificate(null)}
      />
    </section>
  );
}
