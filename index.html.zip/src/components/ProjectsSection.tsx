import { useState } from 'react';
import { ExternalLink, Globe, Layers } from 'lucide-react';
import { PROJECTS_DATA, type ProjectItem } from '../data/portfolioData';
import { filterProjects, type ProjectFilter } from '../utils/portfolioHelpers';

const FILTER_OPTIONS: { label: string; value: ProjectFilter }[] = [
  { label: 'All Projects', value: 'All' },
  { label: 'Practice Project', value: 'Practice Project' },
  { label: 'In Progress', value: 'In Progress' },
];

function ProjectVisualPreview({ project }: { project: ProjectItem }) {
  if (project.previewKind === 'prakriti-farm') {
    return (
      <div
        aria-label={project.previewCaption}
        className="relative overflow-hidden rounded-xl border border-white/10 bg-[#08101F]"
      >
        {/* Minimal browser bar */}
        <div className="flex items-center justify-between border-b border-white/10 bg-[#0C1629] px-4 py-2.5">
          <div className="flex items-center gap-1.5" aria-hidden="true">
            <span className="h-2 w-2 rounded-full bg-white/20" />
            <span className="h-2 w-2 rounded-full bg-white/20" />
            <span className="h-2 w-2 rounded-full bg-white/20" />
          </div>
          <span className="truncate font-mono text-[11px] text-[#94A3B8]">
            pk-prakriti-farm.ai.studio
          </span>
          <Globe className="h-3.5 w-3.5 text-[#60A5FA]" aria-hidden="true" />
        </div>

        {/* Representative UI layout wireframe preview */}
        <div className="p-5 sm:p-6">
          <div className="rounded-lg border border-emerald-400/20 bg-gradient-to-br from-[#0F2420] to-[#0B1726] p-5">
            <p className="text-[11px] font-medium tracking-wide text-emerald-300/90">
              Natural Farming &amp; Sustainable Gardening
            </p>
            <p className="mt-1.5 font-display text-lg font-semibold text-white">
              PK Prakriti Farm
            </p>
            <p className="mt-1 text-xs leading-relaxed text-[#CBD5E1]">
              Agricultural web layout practice exploring organic education and farm experiences.
            </p>

            <div className="mt-4 grid grid-cols-3 gap-2.5">
              <div className="rounded-md border border-white/10 bg-[#08101F]/70 p-2.5">
                <span className="block text-[10px] text-[#94A3B8]">Topic 01</span>
                <span className="mt-0.5 block text-xs font-medium text-white">Soil Care</span>
              </div>
              <div className="rounded-md border border-white/10 bg-[#08101F]/70 p-2.5">
                <span className="block text-[10px] text-[#94A3B8]">Topic 02</span>
                <span className="mt-0.5 block text-xs font-medium text-white">Gardening</span>
              </div>
              <div className="rounded-md border border-white/10 bg-[#08101F]/70 p-2.5">
                <span className="block text-[10px] text-[#94A3B8]">Topic 03</span>
                <span className="mt-0.5 block text-xs font-medium text-white">Farm Visits</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      aria-label={project.previewCaption}
      className="relative overflow-hidden rounded-xl border border-white/10 bg-[#08101F]"
    >
      {/* Minimal browser bar */}
      <div className="flex items-center justify-between border-b border-white/10 bg-[#0C1629] px-4 py-2.5">
        <div className="flex items-center gap-1.5" aria-hidden="true">
          <span className="h-2 w-2 rounded-full bg-white/20" />
          <span className="h-2 w-2 rounded-full bg-white/20" />
          <span className="h-2 w-2 rounded-full bg-white/20" />
        </div>
        <span className="truncate font-mono text-[11px] text-[#94A3B8]">
          personal-portfolio
        </span>
        <Layers className="h-3.5 w-3.5 text-[#60A5FA]" aria-hidden="true" />
      </div>

      {/* Representative UI layout wireframe preview */}
      <div className="p-5 sm:p-6">
        <div className="rounded-lg border border-[#3B82F6]/25 bg-gradient-to-br from-[#0F1E3A] to-[#0A1324] p-5">
          <p className="text-[11px] font-medium tracking-wide text-[#60A5FA]">
            Responsive Student Portfolio
          </p>
          <p className="mt-1.5 font-display text-lg font-semibold text-white">
            Hi, I&apos;m Divya.
          </p>
          <p className="mt-1 text-xs leading-relaxed text-[#CBD5E1]">
            Documenting practice projects, workshop certificates, and CSE-AI learning goals.
          </p>

          <div className="mt-4 grid grid-cols-3 gap-2.5">
            <div className="rounded-md border border-white/10 bg-[#08101F]/70 p-2.5">
              <span className="block text-[10px] text-[#94A3B8]">Section</span>
              <span className="mt-0.5 block text-xs font-medium text-white">Projects</span>
            </div>
            <div className="rounded-md border border-white/10 bg-[#08101F]/70 p-2.5">
              <span className="block text-[10px] text-[#94A3B8]">Section</span>
              <span className="mt-0.5 block text-xs font-medium text-white">Certificates</span>
            </div>
            <div className="rounded-md border border-white/10 bg-[#08101F]/70 p-2.5">
              <span className="block text-[10px] text-[#94A3B8]">Section</span>
              <span className="mt-0.5 block text-xs font-medium text-white">Learning</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function ProjectsSection() {
  const [activeFilter, setActiveFilter] = useState<ProjectFilter>('All');
  const visibleProjects = filterProjects(PROJECTS_DATA, activeFilter);

  return (
    <section
      id="projects"
      aria-labelledby="projects-heading"
      className="border-b border-white/10 bg-[#0A1324] py-16 sm:py-20"
    >
      <div className="mx-auto max-w-6xl px-6">
        <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <div className="max-w-2xl">
            <p className="text-xs font-semibold tracking-wider text-[#60A5FA]">Practice Work</p>
            <h2
              id="projects-heading"
              className="mt-2 font-display text-2xl font-bold tracking-tight text-white sm:text-3xl"
            >
              My Projects
            </h2>
            <p className="mt-3 text-base leading-relaxed text-[#CBD5E1]">
              Personal practice websites built to learn layout design, responsive structure, and AI-assisted development.
            </p>
          </div>

          {/* Interactive filter controls */}
          <div
            role="group"
            aria-label="Filter projects by status"
            className="inline-flex w-fit items-center gap-1 rounded-xl border border-white/10 bg-[#08101F] p-1"
          >
            {FILTER_OPTIONS.map((option) => {
              const isSelected = activeFilter === option.value;
              return (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => setActiveFilter(option.value)}
                  aria-pressed={isSelected}
                  className={`min-h-[38px] rounded-lg px-3.5 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 transition-colors duration-150 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#3B82F6] ${
                    isSelected
                      ? 'bg-[#3B82F6] text-white'
                      : 'text-[#CBD5E1] hover:bg-[#0F1A2E] hover:text-white'
                  }`}
                >
                  {option.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="mt-10 grid gap-8 lg:grid-cols-2" data-testid="projects-grid">
          {visibleProjects.map((project) => (
            <article
              key={project.id}
              className="flex flex-col justify-between rounded-2xl border border-white/12 bg-[#0F1A2E] p-6 transition-colors duration-150 hover:border-[#3B82F6]/45 sm:p-7"
            >
              <div>
                <ProjectVisualPreview project={project} />

                <div className="mt-6 flex flex-col gap-1.5">
                  <span
                    className={`text-xs font-semibold tracking-wide ${
                      project.status === 'Practice Project' ? 'text-[#60A5FA]' : 'text-[#93C5FD]'
                    }`}
                  >
                    {project.status}
                  </span>
                  <h3 className="font-display text-xl font-bold text-white">
                    {project.title}
                  </h3>
                  <p className="text-xs text-[#94A3B8]">
                    {project.technologies.join(' · ')}
                  </p>
                </div>

                <p className="mt-3 text-sm leading-relaxed text-[#CBD5E1] sm:text-base">
                  {project.description}
                </p>
              </div>

              <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-t border-white/10 pt-5">
                {project.liveUrl ? (
                  <a
                    href={project.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-[#3B82F6] px-5 py-2.5 text-sm font-semibold text-white whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-[#2563EB] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#60A5FA]"
                  >
                    <span>{project.ctaLabel ?? 'View Live Project'}</span>
                    <ExternalLink className="h-4 w-4" aria-hidden="true" />
                  </a>
                ) : (
                  <span className="text-sm font-medium text-[#94A3B8]">
                    Status: In Progress — currently being refined
                  </span>
                )}

                {project.repoUrl && (
                  <a
                    href={project.repoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm font-medium text-[#60A5FA] hover:underline hover:underline-offset-4"
                  >
                    Source Repository
                  </a>
                )}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
