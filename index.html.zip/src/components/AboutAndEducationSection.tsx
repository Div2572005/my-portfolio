import { GraduationCap } from 'lucide-react';
import { PORTFOLIO_PROFILE } from '../data/portfolioData';

export function AboutAndEducationSection() {
  const { aboutHeading, aboutParagraphs, education } = PORTFOLIO_PROFILE;

  return (
    <section
      id="about"
      aria-labelledby="about-heading"
      className="border-b border-white/10 bg-[#0A1324] py-16 sm:py-20"
    >
      <div className="mx-auto grid max-w-6xl gap-10 px-6 lg:grid-cols-12 lg:items-start lg:gap-12">
        {/* About Me */}
        <div className="lg:col-span-7">
          <p className="text-xs font-semibold tracking-wider text-[#60A5FA]">Introduction</p>
          <h2
            id="about-heading"
            className="mt-2 font-display text-2xl font-bold tracking-tight text-white sm:text-3xl"
          >
            {aboutHeading}
          </h2>

          <div className="mt-5 space-y-4 text-base leading-relaxed text-[#CBD5E1]">
            {aboutParagraphs.map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
          </div>
        </div>

        {/* Education Card */}
        <div id="education" className="lg:col-span-5">
          <article
            aria-labelledby="education-heading"
            className="rounded-2xl border border-white/12 bg-[#0F1A2E] p-6 sm:p-7"
          >
            <div className="flex items-center gap-3 border-b border-white/10 pb-4">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#3B82F6]/15 text-[#60A5FA]">
                <GraduationCap className="h-5 w-5" aria-hidden="true" />
              </div>
              <div>
                <p className="text-xs font-medium text-[#94A3B8]">Academic Background</p>
                <h3 id="education-heading" className="font-display text-lg font-semibold text-white">
                  Education
                </h3>
              </div>
            </div>

            <dl className="mt-5 space-y-4 text-sm">
              <div>
                <dt className="text-xs font-medium text-[#94A3B8]">Degree</dt>
                <dd className="mt-1 font-medium text-white">{education.degree}</dd>
              </div>
              <div>
                <dt className="text-xs font-medium text-[#94A3B8]">Field of Study</dt>
                <dd className="mt-1 font-medium text-[#E2E8F0]">{education.field}</dd>
              </div>
              <div>
                <dt className="text-xs font-medium text-[#94A3B8]">Institution</dt>
                <dd className="mt-1 font-medium text-[#60A5FA]">{education.institution}</dd>
              </div>
            </dl>

            <p className="mt-5 border-t border-white/10 pt-4 text-xs leading-relaxed text-[#94A3B8]">
              {education.note}
            </p>
          </article>
        </div>
      </div>
    </section>
  );
}
