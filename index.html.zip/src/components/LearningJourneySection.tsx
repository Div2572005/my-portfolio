import { LEARNING_GOALS_DATA } from '../data/portfolioData';

export function LearningJourneySection() {
  return (
    <section
      id="learning-journey"
      aria-labelledby="learning-heading"
      className="border-b border-white/10 bg-[#0A1324] py-16 sm:py-20"
    >
      <div className="mx-auto max-w-6xl px-6">
        <div className="max-w-2xl">
          <p className="text-xs font-semibold tracking-wider text-[#60A5FA]">
            Ongoing Focus
          </p>
          <h2
            id="learning-heading"
            className="mt-2 font-display text-2xl font-bold tracking-tight text-white sm:text-3xl"
          >
            What I&apos;m Learning
          </h2>
          <p className="mt-3 text-base leading-relaxed text-[#CBD5E1]">
            Current learning goals and hands-on activities I am practising as I grow my confidence in web development.
          </p>
        </div>

        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {LEARNING_GOALS_DATA.map((goal) => (
            <article
              key={goal.id}
              className="flex flex-col justify-between rounded-2xl border border-white/12 bg-[#0F1A2E] p-6 sm:p-7"
            >
              <div>
                <span className="font-mono text-xs font-medium text-[#60A5FA] tabular-nums">
                  {goal.number}. Learning Goal
                </span>
                <h3 className="mt-3 font-display text-xl font-semibold text-white">
                  {goal.title}
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-[#CBD5E1] sm:text-base">
                  {goal.description}
                </p>
              </div>

              <p className="mt-6 border-t border-white/10 pt-4 text-xs font-medium text-[#94A3B8]">
                {goal.practiceFocus}
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
