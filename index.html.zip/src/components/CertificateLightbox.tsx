import { useEffect, useRef } from 'react';
import { ExternalLink, FileText, X } from 'lucide-react';
import type { CertificateItem } from '../data/portfolioData';

interface CertificateLightboxProps {
  certificate: CertificateItem | null;
  imageFailed: boolean;
  onImageError: (id: string) => void;
  onClose: () => void;
}

export function CertificateLightbox({
  certificate,
  imageFailed,
  onImageError,
  onClose,
}: CertificateLightboxProps) {
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!certificate) return;

    closeButtonRef.current?.focus();

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [certificate, onClose]);

  if (!certificate) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="lightbox-certificate-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm sm:p-6"
      onClick={(event) => {
        if (event.target === event.currentTarget) {
          onClose();
        }
      }}
    >
      <div className="relative flex max-h-[92vh] w-full max-w-5xl flex-col overflow-hidden rounded-2xl border border-white/15 bg-[#0F1A2E] shadow-2xl">
        {/* Top bar */}
        <div className="flex items-center justify-between gap-4 border-b border-white/10 px-5 py-4 sm:px-6">
          <div className="min-w-0">
            <p className="text-xs font-medium text-[#60A5FA]">
              {certificate.issuer} · {certificate.dateLabel} {certificate.dateValue}
            </p>
            <h3
              id="lightbox-certificate-title"
              className="truncate font-display text-lg font-bold text-white sm:text-xl"
            >
              {certificate.title}
            </h3>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <a
              href={certificate.pdfUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-white/20 bg-[#08101F] px-3.5 py-2 text-xs font-semibold text-white whitespace-nowrap shrink-0 transition-colors hover:border-[#3B82F6] hover:bg-[#16243D] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#3B82F6]"
            >
              <ExternalLink className="h-3.5 w-3.5 text-[#60A5FA]" aria-hidden="true" />
              <span>Open Original PDF</span>
            </a>

            <button
              ref={closeButtonRef}
              type="button"
              onClick={onClose}
              aria-label={`Close ${certificate.title} preview`}
              className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-white/15 bg-[#08101F] text-[#F8FAFC] transition-colors hover:border-white/40 hover:bg-[#16243D] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#3B82F6]"
            >
              <X className="h-5 w-5" aria-hidden="true" />
            </button>
          </div>
        </div>

        {/* Scrollable body */}
        <div className="grid gap-6 overflow-y-auto p-5 sm:p-6 lg:grid-cols-12">
          <div className="flex items-center justify-center rounded-xl border border-white/10 bg-white p-3 lg:col-span-8">
            {imageFailed ? (
              <div className="flex min-h-[300px] w-full flex-col items-center justify-center rounded-lg bg-[#08101F] p-6 text-center text-[#CBD5E1]">
                <FileText className="h-10 w-10 text-[#60A5FA]" aria-hidden="true" />
                <p className="mt-3 font-display text-base font-semibold text-white">
                  {certificate.title}
                </p>
                <p className="mt-1 text-xs text-[#94A3B8]">
                  Preview image unavailable. Open the original PDF file to view the certificate.
                </p>
              </div>
            ) : (
              <img
                src={certificate.imageUrl}
                alt={certificate.altText}
                referrerPolicy="no-referrer"
                onError={() => onImageError(certificate.id)}
                className="max-h-[65vh] w-auto max-w-full object-contain"
              />
            )}
          </div>

          <div className="flex flex-col justify-between gap-6 lg:col-span-4">
            <div className="space-y-4 text-sm">
              <div>
                <p className="text-xs font-medium text-[#94A3B8]">Certificate Title</p>
                <p className="mt-1 font-medium text-white">{certificate.certificateTitle}</p>
              </div>

              <div>
                <p className="text-xs font-medium text-[#94A3B8]">Name Printed on Certificate</p>
                <p className="mt-1 font-medium text-white">{certificate.holderName}</p>
              </div>

              <div>
                <p className="text-xs font-medium text-[#94A3B8]">Issuer</p>
                <p className="mt-1 font-medium text-[#E2E8F0]">{certificate.issuer}</p>
              </div>

              <div>
                <p className="text-xs font-medium text-[#94A3B8]">{certificate.dateLabel}</p>
                <p className="mt-1 font-mono text-xs text-[#E2E8F0] tabular-nums">
                  {certificate.dateValue}
                </p>
              </div>

              <div className="border-t border-white/10 pt-4">
                <p className="text-xs font-medium text-[#94A3B8]">{certificate.topicsLabel}</p>
                <ul className="mt-2 space-y-1.5 text-xs leading-relaxed text-[#CBD5E1]">
                  {certificate.topics.map((topic) => (
                    <li key={topic} className="flex items-baseline gap-2">
                      <span aria-hidden="true" className="text-[#3B82F6]">
                        /
                      </span>
                      <span>{topic}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <p className="border-t border-white/10 pt-4 text-xs leading-relaxed text-[#94A3B8]">
              Original certificate artwork displayed without alteration.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
