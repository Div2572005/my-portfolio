import { SKILLS_DATA } from '../data/portfolioData';

export function SkillsSection() {
  return (
    <section
      id="skills"
      aria-labelledby="skills-heading"
      className="border-b border-white/10 bg-[#08101F] py-16 sm:py-20"
    >
      <div className="mx-auto max-w-6xl px-6">
        <div className="max-w-2xl">
          <p className="text-xs font-semibold tracking-wider text-[#60A5FA]">Capabilities &amp; Growth</p>
          <h2
            id="skills-heading"
            className="mt-2 font-display text-2xl font-bold tracking-tight text-white sm:text-3xl"
          >
            Skills &amp; Learning
          </h2>
          <p className="mt-3 text-base leading-relaxed text-[#CBD5E1]">
            An honest snapshot of the tools I have practised with so far and the foundational skills I am actively developing.
          </p>
        </div>

        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {SKILLS_DATA.map((skill) => {
            const isCurrent = skill.stage === 'current';
            return (
              <article
                key={skill.id}
                className="flex flex-col justify-between rounded-2xl border border-white/12 bg-[#0F1A2E] p-6 transition-colors duration-150 hover:border-[#3B82F6]/45"
              >
                <div>
                  <div className="flex items-center gap-2 text-xs font-medium">
                    <span className={isCurrent ? 'text-[#60A5FA]' : 'text-[#93C5FD]'}>
                      {skill.stageLabel}
                    </span>
                    <span aria-hidden="true" className="text-[#475569]">
                      ·
                    </span>
                    <span className="text-[#94A3B8]">
                      {isCurrent ? 'Hands-on Practice' : 'Active Study'}
                    </span>
                  </div>

                  <h3 className="mt-3 font-display text-lg font-semibold leading-snug text-white">
                    {skill.title}
                  </h3>

                  <p className="mt-3 text-sm leading-relaxed text-[#CBD5E1]">
                    {skill.summary}
                  </p>
                </div>

                <ul className="mt-6 space-y-2 border-t border-white/10 pt-4 text-xs text-[#94A3B8]">
                  {skill.focusAreas.map((area) => (
                    <li key={area} className="flex items-baseline gap-2">
                      <span aria-hidden="true" className="text-[#3B82F6]">
                        /
                      </span>
                      <span>{area}</span>
                    </li>
                  ))}
                </ul>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
