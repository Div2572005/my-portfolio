import { PORTFOLIO_PROFILE } from '../data/portfolioData';
import { BrandLogo } from './BrandLogo';

const NAV_LINKS = [
  { label: 'About', href: '#about' },
  { label: 'Skills', href: '#skills' },
  { label: 'Projects', href: '#projects' },
  { label: 'Certificates', href: '#certificates' },
  { label: 'Learning', href: '#learning-journey' },
];

export function Navbar() {
  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-[#08101F]/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-x-8 gap-y-2 px-6 py-3 md:h-16 md:flex-nowrap md:py-0">
        {/* Zone 1: Brand mark & wordmark */}
        <a
          href="#home"
          className="inline-flex items-center gap-2.5 font-display text-lg font-bold tracking-tight text-[#F8FAFC] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#3B82F6] rounded-sm"
        >
          <BrandLogo size={30} className="shrink-0" />
          <span>{PORTFOLIO_PROFILE.brandName}</span>
        </a>

        {/* Zone 2: Always-visible single-line navigation links */}
        <nav
          aria-label="Primary navigation"
          className="order-3 flex w-full items-center justify-between gap-4 overflow-x-auto border-t border-white/10 pt-2.5 text-xs font-medium text-[#CBD5E1] md:order-2 md:w-auto md:justify-center md:gap-7 md:overflow-visible md:border-t-0 md:pt-0 md:text-sm"
        >
          {NAV_LINKS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="whitespace-nowrap shrink-0 py-1 text-[#CBD5E1] transition-colors duration-150 hover:text-white hover:underline hover:underline-offset-8 hover:decoration-[#3B82F6] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#3B82F6] rounded-sm"
            >
              {item.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: Primary action */}
        <div className="order-2 flex items-center gap-3 shrink-0 md:order-3">
          <a
            href="#contact"
            className="inline-flex items-center justify-center rounded-lg bg-[#3B82F6] px-4 py-2 text-xs font-medium text-white whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-[#2563EB] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#60A5FA] sm:text-sm"
          >
            Contact
          </a>
        </div>
      </div>
    </header>
  );
}
