import { useState } from 'react';
import { Check, Copy, ExternalLink, Linkedin, Mail } from 'lucide-react';
import { CONTACT_CHANNELS } from '../data/portfolioData';
import { getContactHref, isContactConfigured } from '../utils/portfolioHelpers';

export function ContactSection() {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = async (id: string, value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedId(id);
      window.setTimeout(() => {
        setCopiedId((current) => (current === id ? null : current));
      }, 2000);
    } catch {
      // Clipboard API unavailable in restricted contexts; link remains directly clickable
    }
  };

  return (
    <section
      id="contact"
      aria-labelledby="contact-heading"
      className="border-b border-white/10 bg-[#08101F] py-16 sm:py-20"
    >
      <div className="mx-auto max-w-6xl px-6">
        <div className="max-w-2xl">
          <p className="text-xs font-semibold tracking-wider text-[#60A5FA]">Get in Touch</p>
          <h2
            id="contact-heading"
            className="mt-2 font-display text-2xl font-bold tracking-tight text-white sm:text-3xl"
          >
            Contact
          </h2>
          <p className="mt-3 text-base leading-relaxed text-[#CBD5E1]">
            Feel free to connect if you would like to share feedback on my practice projects or talk about AI tools and web development.
          </p>
        </div>

        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {CONTACT_CHANNELS.map((channel) => {
            const configured = isContactConfigured(channel);
            const href = getContactHref(channel);
            const Icon = channel.id === 'email' ? Mail : Linkedin;

            return (
              <div
                key={channel.id}
                className="flex flex-col justify-between rounded-2xl border border-white/12 bg-[#0F1A2E] p-6"
              >
                <div>
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#3B82F6]/15 text-[#60A5FA]">
                      <Icon className="h-5 w-5" aria-hidden="true" />
                    </div>
                    <div>
                      <h3 className="font-display text-lg font-semibold text-white">
                        {channel.label}
                      </h3>
                      <p className="text-xs text-[#94A3B8]">{channel.helperText}</p>
                    </div>
                  </div>

                  <p className="mt-5 break-all rounded-xl border border-white/10 bg-[#08101F] px-4 py-3 font-mono text-xs text-[#E2E8F0] sm:text-sm">
                    {configured ? channel.value : channel.placeholderText}
                  </p>
                </div>

                <div className="mt-5 flex flex-wrap items-center gap-3">
                  {configured && href ? (
                    <>
                      <a
                        href={href}
                        target={channel.id === 'linkedin' ? '_blank' : undefined}
                        rel={channel.id === 'linkedin' ? 'noopener noreferrer' : undefined}
                        className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-[#3B82F6] px-5 py-2.5 text-sm font-semibold text-white whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-[#2563EB] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#60A5FA]"
                      >
                        <span>
                          {channel.id === 'email' ? 'Send Email' : 'Open LinkedIn Profile'}
                        </span>
                        <ExternalLink className="h-4 w-4" aria-hidden="true" />
                      </a>

                      {channel.id === 'email' && (
                        <button
                          type="button"
                          onClick={() => handleCopy(channel.id, channel.value)}
                          className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl border border-white/20 bg-[#08101F] px-4 py-2.5 text-sm font-medium text-[#E2E8F0] whitespace-nowrap shrink-0 transition-colors duration-150 hover:border-[#3B82F6]/70 hover:text-white cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#3B82F6]"
                        >
                          {copiedId === channel.id ? (
                            <>
                              <Check className="h-4 w-4 text-[#60A5FA]" aria-hidden="true" />
                              <span>Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="h-4 w-4 text-[#94A3B8]" aria-hidden="true" />
                              <span>Copy Email</span>
                            </>
                          )}
                        </button>
                      )}
                    </>
                  ) : (
                    <span className="text-xs font-medium text-[#94A3B8]">
                      Placeholder — update <code className="font-mono text-[#CBD5E1]">src/data/portfolioData.ts</code> to enable this link.
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
