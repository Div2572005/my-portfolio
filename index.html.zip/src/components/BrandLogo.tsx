interface BrandLogoProps {
  size?: number;
  className?: string;
}

/**
 * Custom tech-inspired AI & code emblem for Divya's CSE-AI portfolio:
 * Chamfered microchip frame enclosing a geometric code-bracket "D" and connected neural nodes.
 */
export function BrandLogo({ size = 32, className = '' }: BrandLogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      className={className}
    >
      <defs>
        <linearGradient id="techBorderGrad" x1="4" y1="4" x2="36" y2="36" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#60A5FA" />
          <stop offset="100%" stopColor="#2563EB" />
        </linearGradient>
        <linearGradient id="techCoreGrad" x1="12" y1="10" x2="29" y2="30" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#93C5FD" />
          <stop offset="100%" stopColor="#3B82F6" />
        </linearGradient>
      </defs>

      {/* Chamfered microchip outer frame */}
      <path
        d="M9 3H31L37 9V31L31 37H9L3 31V9L9 3Z"
        fill="#0F1A2E"
        stroke="url(#techBorderGrad)"
        strokeWidth="1.75"
      />

      {/* Subtle processor edge traces */}
      <path
        d="M7 15H3.5M7 25H3.5M36.5 15H33M36.5 25H33"
        stroke="#3B82F6"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeOpacity="0.6"
      />

      {/* Primary tech symbol: angled code-core & neural-circuit D-crest */}
      <path
        d="M12.5 11V29M12.5 11H21.5L28 16.5V23.5L21.5 29H12.5"
        stroke="#F8FAFC"
        strokeWidth="2.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Interconnected AI neural lattice & code chevron inside */}
      <path
        d="M17.5 15.5L22.5 20L17.5 24.5M22.5 20H27.5"
        stroke="url(#techCoreGrad)"
        strokeWidth="2.1"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Circuit terminal nodes */}
      <circle cx="17.5" cy="15.5" r="1.8" fill="#60A5FA" />
      <circle cx="17.5" cy="24.5" r="1.8" fill="#60A5FA" />
      <circle cx="22.5" cy="20" r="2.1" fill="#F8FAFC" stroke="#3B82F6" strokeWidth="1.3" />
    </svg>
  );
}
