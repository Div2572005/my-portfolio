import { PORTFOLIO_PROFILE } from '../data/portfolioData';
import { formatCopyrightYear } from '../utils/portfolioHelpers';
import { BrandLogo } from './BrandLogo';

const FOOTER_LINKS = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Skills', href: '#skills' },
  { label: 'Projects', href: '#projects' },
  { label: 'Certificates', href: '#certificates' },
  { label: 'Learning', href: '#learning-journey' },
  { label: 'Contact', href: '#contact' },
];

export function Footer() {
  const copyrightYear = formatCopyrightYear(PORTFOLIO_PROFILE.copyrightStartYear);

  return (
    <footer className="bg-[#060C18] py-10">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-6 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-3.5">
          <BrandLogo size={32} className="shrink-0" />
          <div>
            <p className="text-sm font-medium text-[#E2E8F0]">
              {PORTFOLIO_PROFILE.footerStatement}
            </p>
            <p className="mt-1 text-xs text-[#94A3B8] tabular-nums">
              &copy; {copyrightYear} {PORTFOLIO_PROFILE.brandName}. All rights reserved.
            </p>
          </div>
        </div>

        <nav aria-label="Footer navigation" className="flex flex-wrap items-center gap-x-6 gap-y-2">
          {FOOTER_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-xs font-medium text-[#94A3B8] whitespace-nowrap transition-colors hover:text-white focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#3B82F6] rounded-sm"
            >
              {link.label}
            </a>
          ))}
        </nav>
      </div>
    </footer>
  );
}
