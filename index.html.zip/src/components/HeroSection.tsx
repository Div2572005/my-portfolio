import { ArrowRight, Compass } from 'lucide-react';
import { PORTFOLIO_PROFILE } from '../data/portfolioData';

export function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    const target = document.getElementById(sectionId);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <section
      id="home"
      aria-labelledby="hero-heading"
      className="relative overflow-hidden border-b border-white/10 bg-[#08101F] py-16 sm:py-24 lg:py-28"
    >
      {/* Subtle architectural grid backdrop */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-20"
        style={{
          backgroundImage:
            'linear-gradient(to right, rgba(59, 130, 246, 0.12) 1px, transparent 1px), linear-gradient(to bottom, rgba(59, 130, 246, 0.12) 1px, transparent 1px)',
          backgroundSize: '48px 48px',
        }}
      />

      <div className="relative mx-auto grid max-w-6xl items-stretch gap-12 px-6 lg:grid-cols-12 lg:gap-10">
        {/* Left column: primary typography & CTAs */}
        <div className="animate-fade-up flex flex-col justify-center lg:col-span-7">
          <p className="text-sm font-medium tracking-wide text-[#60A5FA]">
            {PORTFOLIO_PROFILE.heroSubtitle}
          </p>

          <h1
            id="hero-heading"
            className="mt-4 font-display text-4xl font-bold tracking-tight text-white [text-wrap:balance] sm:text-5xl lg:text-6xl"
          >
            {PORTFOLIO_PROFILE.heroHeading}
          </h1>

          <p className="mt-6 max-w-2xl text-base leading-relaxed text-[#CBD5E1] sm:text-lg">
            {PORTFOLIO_PROFILE.heroIntro}
          </p>

          <div className="mt-9 flex flex-wrap items-center gap-4">
            <button
              type="button"
              onClick={() => scrollToSection('projects')}
              className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-[#3B82F6] px-6 py-3 text-sm font-semibold text-white whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-[#2563EB] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#60A5FA] cursor-pointer"
            >
              <span>Explore My Projects</span>
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </button>

            <button
              type="button"
              onClick={() => scrollToSection('learning-journey')}
              className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl border border-white/20 bg-[#0F1A2E] px-6 py-3 text-sm font-semibold text-[#F8FAFC] whitespace-nowrap shrink-0 transition-colors duration-150 hover:border-[#3B82F6]/70 hover:bg-[#16243D] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#60A5FA] cursor-pointer"
            >
              <Compass className="h-4 w-4 text-[#60A5FA]" aria-hidden="true" />
              <span>Discover My Learning Journey</span>
            </button>
          </div>
        </div>

        {/* Right column: clean geometric technology & learning workspace visual */}
        <div className="animate-fade-up-delayed flex items-stretch lg:col-span-5">
          <div className="flex w-full flex-col justify-between rounded-2xl border border-white/12 bg-[#0F1A2E] p-6 sm:p-7">
            <div>
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <span className="font-mono text-xs text-[#94A3B8]">learning-workspace</span>
                <span className="font-mono text-xs text-[#60A5FA]">CSE-AI · Lucknow</span>
              </div>

              {/* Clean architectural wire-frame diagram representing AI + Web Learning */}
              <div className="mt-6 space-y-4">
                <div className="rounded-xl border border-white/10 bg-[#08101F] p-4">
                  <div className="flex items-center justify-between text-xs text-[#94A3B8]">
                    <span>01. Foundations</span>
                    <span className="font-mono text-[#60A5FA]">B.Tech CSE-AI</span>
                  </div>
                  <p className="mt-2 text-sm font-medium text-[#F8FAFC]">
                    Computer Science, AI Concepts &amp; Python Basics
                  </p>
                </div>

                <div className="rounded-xl border border-white/10 bg-[#08101F] p-4">
                  <div className="flex items-center justify-between text-xs text-[#94A3B8]">
                    <span>02. Practice Method</span>
                    <span className="font-mono text-[#60A5FA]">AI-Assisted</span>
                  </div>
                  <p className="mt-2 text-sm font-medium text-[#F8FAFC]">
                    Designing Layouts, Testing Components &amp; Iterating
                  </p>
                </div>

                <div className="rounded-xl border border-[#3B82F6]/30 bg-[#132340] p-4">
                  <div className="flex items-center justify-between text-xs text-[#93C5FD]">
                    <span>03. Active Focus</span>
                    <span className="font-mono">Build &amp; Learn</span>
                  </div>
                  <p className="mt-2 text-sm font-medium text-white">
                    Turning ideas into responsive, accessible web projects
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-6 flex items-center justify-between border-t border-white/10 pt-4 text-xs text-[#94A3B8]">
              <span>Personal Learning Portfolio</span>
              <span aria-hidden="true">·</span>
              <span>Practice &amp; Growth</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
