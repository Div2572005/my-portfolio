export type SkillStage = 'current' | 'learning';

export interface SkillItem {
  id: string;
  title: string;
  stage: SkillStage;
  stageLabel: string;
  summary: string;
  focusAreas: string[];
}

export type ProjectStatus = 'Practice Project' | 'In Progress';

export interface ProjectItem {
  id: string;
  title: string;
  status: ProjectStatus;
  description: string;
  technologies: string[];
  liveUrl?: string;
  repoUrl?: string;
  ctaLabel?: string;
  previewKind: 'prakriti-farm' | 'portfolio';
  previewCaption: string;
}

export interface CertificateItem {
  id: string;
  title: string;
  certificateTitle: string;
  issuer: string;
  holderName: string;
  dateLabel: string;
  dateValue: string;
  description: string;
  topicsLabel: string;
  topics: string[];
  imageUrl: string;
  pdfUrl: string;
  aspectRatioClass: string;
  altText: string;
}

export interface LearningGoalItem {
  id: string;
  number: string;
  title: string;
  description: string;
  practiceFocus: string;
}

export interface ContactChannel {
  id: 'email' | 'linkedin';
  label: string;
  placeholderText: string;
  /**
   * Replace `value` with your actual email address or full LinkedIn profile URL
   * (e.g., "https://www.linkedin.com/in/your-handle") to activate a clickable link.
   */
  value: string;
  helperText: string;
}

export const PORTFOLIO_PROFILE = {
  brandName: 'Divya',
  heroHeading: "Hi, I'm Divya.",
  heroSubtitle: 'CSE-AI Student | Aspiring Web Developer',
  heroIntro:
    "I'm a computer science student exploring artificial intelligence tools and web development. I enjoy learning by building practice projects, experimenting with AI-assisted tools, and turning creative ideas into digital experiences.",
  aboutHeading: 'About Me',
  aboutParagraphs: [
    'I am a B.Tech student studying Computer Science Engineering and Artificial Intelligence (CSE-AI) at the University of Lucknow.',
    'Right now, I am developing my understanding of AI tools, website design, and web development through hands-on practice. Every project I build helps me learn how layouts, responsive structure, and thoughtful user interfaces come together.',
  ],
  education: {
    degree: 'Bachelor of Technology (B.Tech)',
    field: 'Computer Science Engineering and Artificial Intelligence (CSE-AI)',
    institution: 'University of Lucknow',
    note: 'Undergraduate engineering coursework focused on computer science fundamentals and artificial intelligence.',
  },
  footerStatement: 'Built by Divya as part of my learning journey.',
  copyrightStartYear: 2026,
};

export const SKILLS_DATA: SkillItem[] = [
  {
    id: 'ai-tools-web',
    title: 'AI Tools & AI-Assisted Website Building',
    stage: 'current',
    stageLabel: 'Current Experience',
    summary:
      'Using AI-assisted tools to brainstorm website structures, iterate on responsive layouts, and practice building clean web pages.',
    focusAreas: ['Prompt-guided prototyping', 'Iterative layout refinement', 'AI productivity workflows'],
  },
  {
    id: 'web-design-layouts',
    title: 'Exploring Website Design & Layouts',
    stage: 'current',
    stageLabel: 'Current Experience',
    summary:
      'Practising visual hierarchy, typography, spacing, and responsive multi-screen layouts across desktop, tablet, and mobile viewports.',
    focusAreas: ['Responsive page structure', 'Color & contrast balance', 'Component organization'],
  },
  {
    id: 'python-programming',
    title: 'Learning Python Programming Language',
    stage: 'learning',
    stageLabel: 'Currently Developing',
    summary:
      'Building foundational fluency in Python syntax, problem solving, and core programming concepts alongside my CSE-AI studies.',
    focusAreas: ['Core syntax & logic', 'Functions & data structures', 'Foundational problem solving'],
  },
];

/**
 * To add a future project:
 * Append a new object to PROJECTS_DATA with title, status, description,
 * technologies, optional liveUrl/repoUrl, and previewKind.
 */
export const PROJECTS_DATA: ProjectItem[] = [
  {
    id: 'pk-prakriti-farm',
    title: 'PK Prakriti Farm',
    status: 'Practice Project',
    description:
      'A personal practice project exploring agricultural website design, natural farming education, sustainable gardening, and farm experiences. Created as part of my journey learning AI-assisted website development.',
    technologies: ['AI-Assisted Web Design', 'Responsive Layout', 'Agricultural Theme'],
    liveUrl: 'https://pk-prakriti-farm.ai.studio/',
    ctaLabel: 'View Live Project',
    previewKind: 'prakriti-farm',
    previewCaption: 'Layout preview of the PK Prakriti Farm practice website',
  },
  {
    id: 'personal-portfolio',
    title: 'Personal Portfolio Website',
    status: 'In Progress',
    description:
      'My personal portfolio project, created to introduce myself, present my learning journey, and practise building responsive websites with AI tools.',
    technologies: ['React', 'TypeScript', 'Tailwind CSS', 'Responsive UI'],
    previewKind: 'portfolio',
    previewCaption: 'This portfolio site — actively evolving through testing and iteration',
  },
];

/**
 * To replace or add a certificate:
 * 1. Place the PDF in /public/assets/aistudio/ and a crisp preview PNG in /public/assets/certificates/
 * 2. Update the entry below without altering the printed holder name or original artwork.
 */
export const CERTIFICATES_DATA: CertificateItem[] = [
  {
    id: 'hp-life-ai-beginners',
    title: 'AI for Beginners',
    certificateTitle: 'Certificate of Completion',
    issuer: 'HP LIFE / HP Foundation',
    holderName: 'Thaint Nandar Soe',
    dateLabel: 'Presented',
    dateValue: 'June 23, 2026',
    description:
      'Completed an introductory online course exploring AI concepts, data, business applications, and ethical considerations.',
    topicsLabel: 'Topics Covered on Certificate',
    topics: [
      'Fundamental AI concepts and applications',
      'Importance of data in artificial intelligence',
      'Business applications of AI',
      'Ethical implications of AI',
    ],
    imageUrl: '/assets/certificates/hp-life-ai-for-beginners.png?v=2',
    pdfUrl: '/assets/aistudio/AI_certification_pdf_62f9cdb4.pdf',
    aspectRatioClass: 'aspect-[4/3]',
    altText:
      'HP LIFE and HP Foundation Certificate of Completion awarded to Thaint Nandar Soe for completing the AI for Beginners online course, presented June 23, 2026.',
  },
  {
    id: 'be10x-ai-tools-claude',
    title: 'AI Tools & Claude Workshop',
    certificateTitle: 'Certificate of Completion',
    issuer: 'Be10x',
    holderName: 'THAINT NANDAR SOE',
    dateLabel: 'Issued on',
    dateValue: 'October 4, 2026',
    description:
      'Completed a workshop focused on practical applications of AI tools for presentations, data analysis, and coding assistance.',
    topicsLabel: 'Skills Listed on Certificate',
    topics: [
      'Creating presentations using AI',
      'Integration automation and research platforms',
      'Data analysis and coding assistance workflows',
    ],
    imageUrl: '/assets/certificates/be10x-ai-tools-workshop.png?v=2',
    pdfUrl: '/assets/aistudio/Certificate__1__dd32d0b9.pdf',
    aspectRatioClass: 'aspect-[3/2]',
    altText:
      'Be10x Certificate of Completion awarded to THAINT NANDAR SOE for completing the AI Tools & Claude Workshop, issued on October 4, 2026.',
  },
];

export const LEARNING_GOALS_DATA: LearningGoalItem[] = [
  {
    id: 'ai-website-builders',
    number: '01',
    title: 'Exploring AI-powered website builders',
    description:
      'Learning how to structure clear prompts, evaluate generated page architectures, and guide AI-assisted tools to produce clean, accessible web interfaces.',
    practiceFocus: 'Goal: Understand how design intent translates into structured components.',
  },
  {
    id: 'testing-and-iteration',
    number: '02',
    title: 'Improving websites through testing and iteration',
    description:
      'Practising how to review websites across desktop and mobile screen sizes, check navigation and readability, and refine details step by step.',
    practiceFocus: 'Goal: Build reliable habits for visual QA, accessibility, and responsive polish.',
  },
];

export const CONTACT_CHANNELS: ContactChannel[] = [
  {
    id: 'email',
    label: 'Email',
    placeholderText: 'Add your email address (e.g., divya@example.com)',
    value: 'theintnandarsoe57889@gmail.com',
    helperText: 'Send an email directly.',
  },
  {
    id: 'linkedin',
    label: 'LinkedIn',
    placeholderText: 'Add your LinkedIn profile URL (e.g., linkedin.com/in/your-profile)',
    value: 'https://www.linkedin.com/in/thaint-nandar-soe-3309b63b3',
    helperText: 'Connect on LinkedIn.',
  },
];
